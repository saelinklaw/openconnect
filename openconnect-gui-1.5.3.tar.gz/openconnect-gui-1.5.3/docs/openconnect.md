### OpenConnect compilation

The 'openconnect' binary and libraries incl. dependent libraries
used in this project may be actually build and packaged
include libraries/headers dependencies on MSYS2 build environment
or Fedora OS via [these scripts](../contrib/).

These commands and paths may vary...
