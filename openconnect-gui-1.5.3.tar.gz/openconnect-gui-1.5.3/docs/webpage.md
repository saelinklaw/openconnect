### Webpage maintenance
Following stesp summarize how to update OpenConnect-GUI web page,
screen shots and its conten:

1. images/screenshots preaparation:
    - prepare desired screen shots (common width is 650px)
    - checkout project into 'gh-pages' branch
    - create or upload images to e.g. screenshots folder
    - commit & submit - and continue with web-text changes...
2. web page text:
    - open GitHub project settings
    - look for GitHub pages and click "Launch automatic page generator"
    - edit 'markdown' page content
    - click "Continue to layouts"
    - choose 'Tactile' style in list
    - review your changes and finish with clicking to "Publish page"
